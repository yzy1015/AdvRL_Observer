There are total 4 folders in this directory.

std_2, std_4, std_8 folders contain python files and jupyter notebook which run and plot results of simulation.

Adversarial bound for std_2, std_4 and std_8 are 2 std, 4 std and 8 std respectively, Jupyter notebook plot_trials.ipynb plot result of all trials. run shell script run.sh will run all python files.

Folder other contain result of adversary without observer and performance of inverted pendulum wihtout noise.

To run the code, need to install Roboschool and OpenAI baselines