#!/bin/bash

python3 seq1.py &

python3 seq2.py &

python3 seq3.py &

python3 seq4.py &

python3 seq5.py &

python3 sim1.py &

python3 sim2.py &

python3 sim3.py &

python3 sim4.py &

python3 sim5.py &
